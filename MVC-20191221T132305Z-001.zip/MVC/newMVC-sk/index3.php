<?php
include "Models/subject_model.php";
include "Controllers/subject_controller.php";
include "Views/template.php";