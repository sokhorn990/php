<?php

$connection = mysqli_connect('localhost','root','','mvc_version2');