<?php
include "Models/class_model.php";
include "Controllers/class_controller.php";
include "Views/template.php";