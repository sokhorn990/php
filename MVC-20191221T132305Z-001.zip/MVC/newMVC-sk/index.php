<?php
include "Models/student_model.php";
include "Controllers/student_controller.php";
include "Views/template.php";